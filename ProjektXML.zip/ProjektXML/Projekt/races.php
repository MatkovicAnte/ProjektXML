<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bootstrap demo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary" class="navbar bg-dark border-bottom border-bottom-dark" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand">Formula1</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="pocetna.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="races.php">Races</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="drivers.php">Drivers</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-danger" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>


            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

<div class="card-group">
  <div class="card">
    <img src="bahrain.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Gulf Air Bahrain Grand Prix</h5>
      <p class="card-text">The 2023 Bahrain Grand Prix (officially known as the Formula 1 Gulf Air Bahrain Grand Prix 2023) was a Formula One motor race that was held on 5 March 2023 at the Bahrain International Circuit in Sakhir, Bahrain.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 57</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/2023_Bahrain_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>


  <div class="card">
    <img src="saudia arabia.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">STC Saudi Arabian Grand Prix</h5>
      <p class="card-text">The 2023 Saudi Arabian Grand Prix (officially known as the Formula 1 STC Saudi Arabian Grand Prix 2023) was a Formula One motor race that was held on 19 March 2023 at the Jeddah Corniche Circuit in Jeddah, Saudi Arabia.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 50</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/2023_Saudi_Arabian_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="australia.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Rolex Australian Grand Prix</h5>
      <p class="card-text">The 2023 Australian Grand Prix (officially known as the Formula 1 Rolex Australian Grand Prix 2023) was a Formula One motor race held on 2 April 2023 at the Albert Park Circuit in Melbourne, Victoria, Australia.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 58</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/2023_Australian_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>
</div>



            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>


<div>
<div class="card-group">
  <div class="card">
    <img src="azerbaijan.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Azerbaijan Grand Prix</h5>
      <p class="card-text">The Azerbaijan Grand Prix (Azerbaijani: Azərbaycan Qran Prisi) is a Formula One motor racing event that was held for the first time in 2017.[a][1][2] It is held on the Baku City Circuit, a street circuit in Baku, the capital of Azerbaijan.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 51</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Azerbaijan_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="miami.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Crypto.com Miami Grand Prix</h5>
      <p class="card-text">The 2023 Miami Grand Prix (officially known as the Formula 1 Crypto.com Miami Grand Prix 2023) was a Formula One motor race held on May 7, 2023, at the Miami International Autodrome in Miami Gardens, Florida. The race was won by Max Verstappen from ninth, ahead of Sergio Pérez and Fernando Alonso.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 57</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/2023_Miami_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="imola.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">	Qatar Airways Emilia Romagna Grand Prix</h5>
      <p class="card-text">The 2023 Emilia Romagna Grand Prix (officially known as the Formula 1 Qatar Airways Gran Premio del Made in Italy e dell'Emilia-Romagna 2023) was a scheduled Formula One motor race set to be held on 21 May 2023, at the Autodromo Internazionale Enzo e Dino Ferrari in Imola, Italy. On 17 May, Formula One Management announced the cancellation of the race due to sudden floods in the region.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 63</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/2023_Emilia_Romagna_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>
</div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

<div>
<div class="card-group">
  <div class="card">
    <img src="monaco.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Monaco Grand Prix</h5>
      <p class="card-text">The Monaco Grand Prix (French: Grand Prix de Monaco) is a Formula One motor racing event held annually on the Circuit de Monaco, in late May or early June. Run since 1929, it is widely considered to be one of the most important and prestigious automobile races in the world.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 78</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Monaco_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="spain.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">AWS Spanish Grand Prix</h5>
      <p class="card-text">The 2023 Spanish Grand Prix (officially known as the Formula 1 AWS Gran Premio de España 2023) was a Formula One motor race that was held on 4 June 2023 at the Circuit de Barcelona-Catalunya in Montmeló, Spain. After taking pole position, Max Verstappen of Red Bull Racing led every lap, took the fastest lap, and won the race ahead of Lewis Hamilton and George Russell, earning him his third career grand slam.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 66</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/2023_Spanish_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="canada.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Pirelli Canada Grand Prix</h5>
      <p class="card-text">The 2022 Canadian Grand Prix (officially known as the Formula 1 AWS Grand Prix du Canada 2022) was a Formula One motor race, which was held on 19 June 2022 at the Circuit Gilles Villeneuve in Montreal, Quebec, Canada. It was the 9th round of the 2022 Formula One World Championship.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 70</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/2022_Canadian_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>
</div>


            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>


<div>
<div class="card-group">
  <div class="card">
    <img src="austria.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Rolex Austrian Grand Prix</h5>
      <p class="card-text">The Austrian Grand Prix (German: Großer Preis von Österreich) is a Fédération Internationale de l'Automobile sanctioned motor racing event that was held in 1964, 1970–1987, 1997–2003, and then returned to the Formula One calendar in 2014.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 71</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Austrian_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="british.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Aramco British Grand Prix</h5>
      <p class="card-text">The British Grand Prix is a Grand Prix motor race organised in the United Kingdom by the Royal Automobile Club. First held in 1926, the British Grand Prix has been held annually since 1948 and has been a round of the FIA Formula One World Championship every year since 1950.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 52</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/British_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="hungary.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Qatar Airways Hungarian Grand Prix</h5>
      <p class="card-text">The Hungarian Grand Prix (Hungarian: Magyar Nagydíj) is a motor racing event held annually in Mogyoród. Since 1986, the race has been a round of the FIA Formula One World Championship.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 70</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Hungarian_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>
</div>


              <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>


<div>
<div class="card-group">
  <div class="card">
    <img src="spa.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">MSC Cruises Belgian Grand Prix</h5>
      <p class="card-text">The Belgian Grand Prix (French: Grand Prix de Belgique; Dutch: Grote Prijs van België; German: Großer Preis von Belgien) is a motor racing event which forms part of the Formula One World Championship. The first national race of Belgium was held in 1925 at the Spa region's race course.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 44</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Belgian_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="dutch.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Heineken Dutch Grand Prix</h5>
      <p class="card-text">The Dutch Grand Prix (Dutch: Grote Prijs van Nederland) is a Formula One motor racing event held at Circuit Zandvoort, North Holland, the Netherlands, from 1950 to 1985 and from 2021 onwards. It was a part of the World Championship from 1952, and designated the European Grand Prix twice, in 1962 and 1976, when this title was an honorary designation given each year to one Grand Prix race in Europe.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 72</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Dutch_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="italy.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Pirelli Italian Grand Prix</h5>
      <p class="card-text">The Italian Grand Prix (Italian: Gran Premio d'Italia) is the fifth oldest national Grand Prix (after the French Grand Prix, the United States Grand Prix, the Spanish Grand Prix and the Russian Grand Prix), having been held since 1921. In 2013 it became the most held Grand Prix (the 2022 edition was the 92nd).</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 53</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Italian_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>
</div>


            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>


<div>
<div class="card-group">
  <div class="card">
    <img src="singapore.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Singapore Airlines Singapore Grand Prix</h5>
      <p class="card-text">The Singapore Grand Prix[a] is a motor racing event which forms part of the Formula One World Championship. The event takes place on the Marina Bay Street Circuit and was the inaugural night race and first street circuit in Asia designed for Formula One races.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 63</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Singapore_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="japan.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Lenovo Japanese Grand Prix</h5>
      <p class="card-text">The Japanese Grand Prix is a motor racing event in the calendar of the Formula One World Championship. Historically, Japan has been one of the last races of the season, and as such the Japanese Grand Prix has been the venue for many title-deciding races.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 53</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Japanese_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="qatar.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Qatar Airways Qatar Grand Prix</h5>
      <p class="card-text">The Qatar Grand Prix is a Formula One motor racing event which is held in Qatar. It was held for the first time on 21 November as part of the 2021 championship at the Lusail International Circuit, and after not taking place during the 2022 season due to the 2022 FIFA World Cup taking place in Qatar, it will rejoin the calendar in 2023 under a 10-year contract.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 57</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Qatar_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>
</div>


            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>


<div>
<div class="card-group">
  <div class="card">
    <img src="usa.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Lenovo United States Grand Prix</h5>
      <p class="card-text">The United States Grand Prix is a motor racing event that has been held on and off since 1908, when it was known as the American Grand Prize. The Grand Prix later became part of the Formula One World Championship. As of 2022, the Grand Prix has been held 51 times at ten different locations.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 56</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/United_States_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="mexico.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Mexico City Grand Prix</h5>
      <p class="card-text">The Mexican Grand Prix, currently held under the name Mexico City Grand Prix, is a motor racing event held at the Autódromo Hermanos Rodríguez in Mexico City. It first appeared as a non-championship event in 1962 before being held as a championship event in 1963–1970 and 1986–1992.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 71</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Mexican_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="brazil.jpg" class="card-img-top" alt="..." height="360px">
    <div class="card-body">
      <h5 class="card-title">Rolex São Paulo Grand Prix</h5>
      <p class="card-text">The Brazilian Grand Prix, currently held under the name São Paulo Grand Prix, is a Formula One championship race which is currently held at the Autódromo José Carlos Pace in Interlagos neighborhood, Cidade Dutra, São Paulo.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 71</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Brazilian_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>
</div>


            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>


<div>
<div class="card-group">
  <div class="card">
    <img src="la.jpg" class="card-img-top" alt="..." height="500px">
    <div class="card-body">
      <h5 class="card-title">Heineken Las Vegas Grand Prix</h5>
      <p class="card-text">The Las Vegas Grand Prix is a planned Formula One Grand Prix due to form part of the 2023 Formula One World Championship, with the event taking place in Las Vegas, Nevada, on a temporary street circuit including the Las Vegas Strip.[1][2] The first race is scheduled for November 18, 2023.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 50</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Las_Vegas_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>

  <div class="card">
    <img src="abu.jpg" class="card-img-top" alt="..." height="500px">
    <div class="card-body">
      <h5 class="card-title">Etihad Airways Abu Dhabi Grand Prix</h5>
      <p class="card-text">The Abu Dhabi Grand Prix is a Formula One motor racing event. It was announced in early 2007 at the Abu Dhabi F1 Festival in the United Arab Emirates. The first race took place on 1 November 2009, held at the Hermann Tilke-designed Yas Marina Circuit.</p>
      <p class="card-text"><small class="text-body-secondary">Number of laps: 58</small></p>
      <p class="card-text"><small class="text-body-secondary" class="text-reset"><a href="https://en.wikipedia.org/wiki/Abu_Dhabi_Grand_Prix">More about the race</a></small></p>
    </div>
  </div>
</div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-12 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-0 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html>