<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bootstrap demo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary" class="navbar bg-dark border-bottom border-bottom-dark" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand">Formula1</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="pocetna.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="races.php">Races</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="drivers.php">Drivers</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-danger" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12" ><p style="padding: 0;"><h1>FIND OUT EVERYTHING ABOUT F1</h1></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-1 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-10 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-1 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

<div class="text-center">
  <img src="news1.jpg" class="rounded-5" alt="..." width="900px">
</div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12" ><p style="padding: 0;">  <h3>Behind the scenes with Pierre Gasly: The Alpine racer on football, fans and frustration in Spain and Monaco</h3></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>
            
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12"><p style="padding: 0;" >  <h6 class="opacity-50">Hey everyone, the past month or so has been pretty hectic with the Monaco-Spain double header and so many different things happening on and off track in that time. Here, I share with you some of those moments and what’s been on my mind of late…</h6></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12"><p style="padding: 0;" >    
                        <p class="text-body-secondary">
                        <a href="https://www.formula1.com/en/latest/article.behind-the-scenes-with-pierre-gasly-the-alpine-racer-on-football-fans-and.6bKiUkKeH4QgBAjs5Frhh1.html" class="text-reset">READ MORE</a></p></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-1 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-10 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-1 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>





<div class="text-center">
  <img src="news2.jpg" class="rounded-5" alt="..." width="900px">
</div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12" ><p style="padding: 0;">  <h3>F1 design legend Newey reveals two times he was tempted by Ferrari move</h3></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>
            
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12"><p style="padding: 0;" >  <h6 class="opacity-50">Adrian Newey has admitted that there were a couple of occasions earlier in his Formula 1 career when he came close to joining Ferrari, describing the allure of the famous Italian manufacturer as “very tempting”...</h6></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12"><p style="padding: 0;" >    
                        <p class="text-body-secondary">
                        <a href="https://www.formula1.com/en/latest/article.f1-design-legend-newey-reveals-two-times-he-was-tempted-by-ferrari-move.xfGJieDOE2CXEUdPsjqUX.html" class="text-reset">READ MORE</a></p></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-1 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-10 col-sm-12 col-md-12"><p style="padding: 0;"><hr class="border border-danger border-3 opacity-100"></p></div>
                    <div class="col-lg-1 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

            



<div class="text-center">
  <img src="news3.jpg" class="rounded-5" alt="..." width="900px">
</div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12" ><p style="padding: 0;">  <h3>Hamilton points to ‘something in the pipeline’ for Mercedes as he eyes Red Bull fight by end of season</h3></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>
            
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12"><p style="padding: 0;" >  <h6 class="opacity-50">Lewis Hamilton has expressed hope that Mercedes will be in a position to challenge Red Bull by the end of the season, saying there should be more to come from the team after their double podium finish in Spain...</h6></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12 col-md-12"><i class="fas fa-globe"></i></div>
                    <div class="col-lg-6 col-sm-12 col-md-12"><p style="padding: 0;" >    
                        <p class="text-body-secondary">
                        <a href="https://www.formula1.com/en/latest/article.hamilton-points-to-something-in-the-pipeline-for-mercedes-as-he-eyes-red.4lrAJDmumTb8KwGWNsZvR0.html" class="text-reset">READ MORE</a></p></p></div>
                    <div class="col-lg-3 col-sm-12 col-md-12"><p style="padding: 0;"></p></div>
                </div>
            </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html>